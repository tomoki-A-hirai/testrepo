<?php
// $count = 0;
// $count = trim(fgets(STDIN));
//
// for($i = 0;$i < $count;$i++){
//   echo "Hello" . $i . PHP_EOL;
// }
for($i = 1;$i<101;$i++){
  if((49 < $i && $i <60)
      ||
    (79 < $i && $i <90)){
    echo "*$i*" . PHP_EOL;
  }else{
    echo $i . PHP_EOL;
  }
}


// for($i = 1;$i<101;$i++){
//   if($i < 50 || (59 < $i && $i < 80) || 89 < $i ){
//     echo $i . PHP_EOL;
//   }else{
//     echo "*$i*" . PHP_EOL;
//   }
// }
