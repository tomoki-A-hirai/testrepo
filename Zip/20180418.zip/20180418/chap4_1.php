<?php
  // $i = 0;
  // while($i < 5){
  //   echo "Hello" . (5- $i) . PHP_EOL;
  //   $i++;
  // }


  $i = 5;
  while($i > 0){
    echo "Hello" . $i . PHP_EOL;
    $i--;
  }
