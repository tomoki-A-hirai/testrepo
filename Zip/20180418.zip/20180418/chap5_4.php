<?php
$scores = [[92, 80, 50, 80], [50, 66, 40]];
// echo $scores[0][0] . PHP_EOL;
// echo $scores[0][1] . PHP_EOL;
// echo $scores[1][0] . PHP_EOL;
// echo $scores[1][1] . PHP_EOL;

// for($i = 0; $i < 2; $i++){
//   for($j= 0; $j < 2; $j++){
//     echo $scores[$i][$j] . PHP_EOL;
//   }
// }

for($i = 0; $i < count($scores); $i++){
  for($j= 0; $j < count($scores[$i]); $j++){
    echo $scores[$i][$j] . PHP_EOL;
  }
}


// foreach ($scores as $score) {
//   foreach ($score as $s) {
//     echo $s . PHP_EOL;
//   }
// }
