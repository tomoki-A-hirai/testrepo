<?php
for($i = 0; $i < 5; $i++){
  for($j = 0; $j < 5; $j++){
    if($j >= (4-$i)){
      echo "*";
    }else{
      echo " ";
    }
  }
  echo PHP_EOL;
}
