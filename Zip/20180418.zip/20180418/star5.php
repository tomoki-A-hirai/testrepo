<?php
for($i = 0; $i < 5; $i++){
  for($j = 0; $j < 10; $j++){
    if((4-$i) <= $j && $j <= (4+$i)){
      echo "*";
    }else{
      echo "Y";
    }
  }
  echo PHP_EOL;
}


echo PHP_EOL;


for($i = 0; $i < 5; $i++){
  for($j = 3; $j >= $i ;$j--){
    echo "X";
  }
  for($k = 0; $k < ($i*2) + 1;$k++){
    echo "*";
  }
  echo PHP_EOL;
}
