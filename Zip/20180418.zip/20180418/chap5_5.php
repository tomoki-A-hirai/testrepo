<?php
$ages = [20, 25, 18, 23, 24];
$sum = 0;
$sumAge = 0;
$max = 0;

// for($i = 0; $i < count($ages); $i++){
//   $sum += $ages[$i];
// }
//
// echo "sum = $sum" . PHP_EOL;
//
//
// foreach ($ages as $age) {
//   $sumAge += $age;
// }
//
// echo "sumAge = $sumAge" . PHP_EOL;

for($i = 0; $i < count($ages); $i++){
  if($max < $ages[$i]){
    $max = $ages[$i];
  }
}
echo "maxAge = $max ";
// foreach ($ages as $age) {
//   if($max < $age){
//     $max = $age;
//   }
// }
// echo "maxAge = $max ";
