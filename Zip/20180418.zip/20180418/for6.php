<?php
$evenTotal = 0;
for($i = 0; $i < 11; $i++ ){
  if($i % 2 == 0){
    $evenTotal += $i;
  }
}

echo $evenTotal;
