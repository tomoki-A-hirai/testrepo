<?php
$points = [64, 76, 58, 72, 48];
$min = $points[0];
// $max = 0;
//
// for($i = 0; $i < count($points); $i++){
//   if($max < $points[$i]){
//     $max = $points[$i];
//   }
// }
//
// $min = $max;
//
for($i = 0; $i < count($points); $i++){
  if($min > $points[$i]){
    $min = $points[$i];
  }
  // echo "now min = $min" . PHP_EOL;
}

echo "min = $min";
