<?php
//$scores = array(92,80.,50,66);
$scores = [92, 80, 50, 66, 88];
$scores[4] = 100;
$scores[] = 100;
//
// echo $scores[0] . PHP_EOL;
// echo $scores[1] . PHP_EOL;
// echo $scores[2] . PHP_EOL;
// echo $scores[3] . PHP_EOL;


for($i = 0; $i < count($scores); $i++){
  echo $scores[$i] . PHP_EOL;
}

// foreach ($scores as $score) {
//   echo $score . PHP_EOL;
// }
