<?php
$points = [64, 76, 58, 72, 48];

foreach ($points as $point) {
  echo $point . PHP_EOL;
}
