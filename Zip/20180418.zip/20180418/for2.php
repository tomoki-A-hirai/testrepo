<?php
  $countMax = 101;
  for($i = 1;$i < $countMax;$i++){
    echo $countMax - $i . PHP_EOL;
  }
