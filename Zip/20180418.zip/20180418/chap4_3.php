<?php
  // $evenTotal = 0;
  // $oddTotal = 0;
  // for($i = 0;$i<101;$i++){
  //   if($i % 2 == 0){
  //     //even
  //     $evenTotal += $i;
  //   }else{
  //     //odd
  //     $oddTotal += $i;
  //   }
  // }
  //
  // echo "evenTotal = $evenTotal" . PHP_EOL ."oddTotal = $oddTotal";


  $total = 0;
  for($i = 0; $i < 101; $i++){
    //echo $i . PHP_EOL;
    $total += $i;
  }
  echo "total = $total";
