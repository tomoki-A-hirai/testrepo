<?php
  for($i = 0; $i < 11;$i++){
    if($i % 2 == 0){
      echo "evenNum =  $i " .PHP_EOL;
    }
  }
