<?php
$scores = [92, 80, 50, 66];

foreach ($scores as $score) {
  echo $score . PHP_EOL;
}
