<?php
  $total = 0;
  for($i = 0; $i < 11; $i++ ){
    $total += $i;
  }

  echo $total;
