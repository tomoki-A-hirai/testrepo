<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body style = "background-color:blue;color:white;">
    an odd page.
  </body>
</html>
