<?php 
$fruits = $_POST["fruits"];
$type = $_POST["type"];

$color = "black";
if($fruits === "apple" || $fruits === "cherry"){
	$color = "red";
}elseif($fruits ==="banana"){
	$color = "yellow";
}

?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <div style = "color:<?= $color ?>">
      <?= $fruits."/".$type; ?>
    </div>
  </body>
</html>
