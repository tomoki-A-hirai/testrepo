<?php
  $param = $_GET["size"];
  switch ($param) {
    case 'l':
      $size = "60px";
      $text = "Large";
      break;
    case 'm':
      $size = "30px";
      $text = "Medium";
      break;
    case 's':
      $size = "1px";
      $text = "Small";
      break;

    default:
      $size ="30";
      $text = "Medium";
      break;
  }
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <span style="font-size:<?= $size ?>"><?= $text ?></span>
  </body>
</html>
