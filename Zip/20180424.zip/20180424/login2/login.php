﻿<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <img src="../logo.png" alt="show logo png">
    <hr>
    <form action="./login_controller.php" method="post">
      <div>
        ユーザID <input type="text" name="userID">
      </div>
      <div>
        パスワード <input type="password" name="password">
      </div>
      <div>
        <input type="submit" value="ログイン">
      </div>
    </form>
    <a href="entry.php">新規登録の方はこちら</a>
  </body>
</html>
