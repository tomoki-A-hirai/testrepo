<?php
function login($userID,$password){
  //load fike data
  $lines = file("../../csv/user.csv" , FILE_IGNORE_NEW_LINES );
  foreach ($lines as $line) {
    $user = explode(",", $line);
    if($userID == $user[0] && $password == $user[1]){
      return true;
    }
  }
  return false;
}

$userID = $_POST["userID"];
$password = $_POST["password"];
$auth = login($userID,$password);

if($auth){
  session_start();
  $_SESSION["userID"] = $userID;
  header("Location: ./menu.php");
  // include("menu.php");
}else{
  header("Location: ./login.php");
  // include("login.php");
}
