<?php
function entry($comment,$userID,$date){
  $line = "$comment,$userID,$date" . PHP_EOL;
   file_put_contents("../../csv/tweet.csv",$line,FILE_APPEND);
  //$tweets = $file("../csv/tweet.csv",FILE_IGNORE_NEW_LINES);

}

$comment = $_POST["tweetBody"];
if($comment != ""){
  session_start();
  $userID = $_SESSION["userID"];
  $date = date("Y-m-d h:i:s");
  $escapedComment = htmlspecialchars($comment);
  entry($escapedComment,$userID,$date);

}

header("Location: ./tweet.php");
