<?php
// session start
session_start();

//get userID
$userID = $_SESSION["userID"];
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <img src="../logo.png" alt="show logo png">
    <?= "login user = $userID"; ?>
    <hr>
    <ul>
      <li> <a href="./tweet.php">tweet</a> </li>
      <li>Menu2</li>
      <li>Menu3</li>
    </ul>
    <a href="./login.php">return to login</a>
  </body>
</html>
