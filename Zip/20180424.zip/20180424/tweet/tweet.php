<?php
// session start
session_start();
//get userID
$userID = $_SESSION["userID"];
$tweets = file("../../csv/tweet.csv", FILE_IGNORE_NEW_LINES);
$tweets = array_reverse($tweets);
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <img src="../logo.png" alt="show logo png">
    <?= "login user = $userID"; ?>
    <hr>
    <form action="tweet_controller.php" method="post">
      <div>
        <input type="text" name="tweetBody">
      </div>
      <div>
        <input type="submit" value="tweet">
      </div>
    </form>
    <br>
    <ul>
      <?php foreach($tweets as $tweet): ?>
      <?php $tweetArray = explode(",", $tweet); ?>
        <li><span style="font-size:25px;"><?= $tweetArray[0] ?></span> <span style="font-size:15px;"><?= "(". $tweetArray[1]."/".$tweetArray[2].")" ?></span></li>
      <?php endforeach; ?>
    </ul>
    <a href="./menu.php">戻る</a>
  </body>
</html>
