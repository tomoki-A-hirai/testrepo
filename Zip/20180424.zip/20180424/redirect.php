<?php
header("Location: ./hello.html");
?>
