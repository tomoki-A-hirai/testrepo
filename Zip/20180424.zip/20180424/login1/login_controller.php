<?php
$userID = $_POST["userID"];
$password = $_POST["password"];

if($userID === "itc" && $password === "201804c"){
  session_start();
  $_SESSION["userID"] = $userID;
  header("Location: ./menu.php");
  // include("menu.php");
}else{
  header("Location: ./login.php");
  // include("login.php");
}
