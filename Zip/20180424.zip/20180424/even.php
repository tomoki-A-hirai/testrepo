<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body style = "background-color:red;color:white;">
    an even page.
  </body>
</html>
