<?php
//  create rand num
$number = rand(1,10);
if($number % 2 === 0){
  include("even.php");
  // header("Location: ./even.php");
}else{
  include("odd.php");
  // header("Location: ./odd.php");
}
