<?php
function entry($userID,$password){
  $line = $userID . "," . $password;
  file_put_contents("../csv/user.csv",$line,FILE_APPEND);
}


$userID = $_POST["userID"];
$password = $_POST["password"];

if($userID !== "" && $password !== ""){
  entry($userID,$password);
  session_start();
  $_SESSION["userID"] = $userID;
  header("Location: ./menu.php");
}else{
  header("Location: ./entry.php");
}
