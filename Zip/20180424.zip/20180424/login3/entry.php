<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <img src="../logo.png" alt="sho logo png">
    <hr>
    <form action="./entry_controller.php" method="post">
      <div>
        ユーザID <input type="text" name="userID">
      </div>
      <div>
        パスワード <input type="password" name="password">
      </div>
      <div>
        <input type="submit"value="新規登録">
      </div>
    </form>
  </body>
</html>
