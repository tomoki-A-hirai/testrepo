<?php
$str = "Object Oriented Programming";
$result = strlen($str);
echo $result ."\r\n";
