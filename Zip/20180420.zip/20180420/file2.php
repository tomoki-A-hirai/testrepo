<?php
$points = [64, 76, 58, 72, 48];
$handle = fopen("array.txt", "a");

for($i = 0; $i < count($points); $i++){
  fwrite($handle,"$points[$i]\r\n");
}

fclose($handle);
