<?php
$ages = [22, 21, 22, 25, 38];
$ascs = [];
$min = 999;
$flag = true;
$swapCount = 0;

while($flag){
  $swapCount = 0;
  $min = 999;
  for ($i=0; $i < count($ages) ; $i++) {
    if($min > $ages[$i]){
      $min = $ages[$i];
      $swapCount++;
    }
  }
  for ($i=0; $i < count($ages) ; $i++) {
    if($min == $ages[$i]){
      $ages[$i] = 999;
      break;
    }
  }
  if($swapCount == 0){
    $flag =false;
    break;
  }
  $ascs[] = $min;
}

// echo "Asc:";
// for ($i=0; $i < count($ascs); $i++) {
//   if($i == (count($ascs)-1)){
//     echo " $ascs[$i]";
//   }else{
//     echo " $ascs[$i],";
//   }
// }

echo $ascs[count($ascs)-2];
