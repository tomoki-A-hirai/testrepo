<?php
$str = "Object Oriented Programming";

$result = substr($str,0, 6);
echo $result . PHP_EOL;


$result = substr($str,7, 8);
echo $result. PHP_EOL;


$result = substr($str,16, 11);
echo $result. PHP_EOL;
