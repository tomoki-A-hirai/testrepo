<?php
$outputTxt = "!Hello PHP\r\n";

$handle = fopen("./output.txt" , "a");
fwrite($handle , $outputTxt);
fclose($handle);
