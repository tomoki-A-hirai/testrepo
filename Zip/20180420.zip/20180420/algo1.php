<?php
$numbers = [12, 23, -14, -25, 0, 36];

foreach ($numbers as $num) {
  if($num > 0){
    echo $num . PHP_EOL;
  }
}
