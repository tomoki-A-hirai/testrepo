<?php
$str = "IT CARET";
echo substr($str,3,8);
