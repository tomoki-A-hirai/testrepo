<?php

$outputTxt = "Hello file_put_contents World \r\n";
file_put_contents("output5.txt",$outputTxt,FILE_APPEND);
