<?php
$str = "Object Oriented Prgramming";

$result = strtoupper($str);
echo $result . PHP_EOL;
echo $str . PHP_EOL;

$result = strtolower($str);
echo $result . PHP_EOL;
