<?php
$handle = fopen("../20180419/csv/scores.csv", "r");
$sum = 0;
while($line = fgets($handle)){
  $results = explode(",", $line);
  // $sum += (int)$results[2];
  $sum += rtrim($results[2]);
}

echo "sum = $sum";
fclose($handle);
