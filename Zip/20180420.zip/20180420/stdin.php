<?php
while (true) {
  echo "Who are the best man?";
  $line = rtrim(fgets(STDIN));
  if ($line == "murayamasan") {
    echo "That's right";
    break;
  }elseif ($line = "murayama") {
    echo "san wo tukeroyo dekosuke yarou!!!!";
  }else {
    echo "NG";
  }
}
