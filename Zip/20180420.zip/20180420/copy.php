<?php
//output.txt > output.bk

//copy("./output.txt" , "output.bk");

mkdir("./backup");
copy("./output.txt" , "./backup/output.bk");
