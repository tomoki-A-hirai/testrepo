<?php
function my_abs($array){
  for ($i=0; $i < count($array); $i++) {
    if ($array[$i] < 0) {
      $array[$i] = 0 - $array[$i];
    }
  }
  return $array;
}

function my_total($array){
  $sum = 0;
  foreach ($array as $val) {
    $sum += $val;
  }
  return $sum;
}


$numbers = [12, 23, -14, -25, 0, 36];
$numbers = my_abs($numbers);
$total = my_total($numbers);
echo $total . PHP_EOL;
