<?php
copy("./date.txt", "copy.txt");
