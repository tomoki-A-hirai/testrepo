<?php
$array = ["Object", "おりえんてっど", "Programming"];
$result = implode(" ",$array);
echo $result . PHP_EOL;
