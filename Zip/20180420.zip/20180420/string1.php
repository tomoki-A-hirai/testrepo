<?php
$str = "IT CARET";
echo strtolower($str);
