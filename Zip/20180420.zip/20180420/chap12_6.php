<?php
function make_capital($str){
  $results = explode(" ",$str);
  foreach ($results as $result) {
    echo strtoupper(mb_substr($result,0,1));
  }
}


// $str = "hyper text markup language";
// $str = "cascading style sheet";
$str = "object oriented programming";
$str = "おぶじぇくと おりえんてっど ぷろぐらみんぐ";
make_capital($str);
