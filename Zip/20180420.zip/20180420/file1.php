<?php
$now = date("Y-m-d H:i:s");
echo "now = $now";

$handle = fopen("date.txt", "w");
fwrite($handle, $now);
fclose($handle);
