<?php
$numbers = [12, 23, -14, -25, 0, 36];
$max = 0;
foreach ($numbers as $num) {
    if ($max < $num) {
      $max = $num;
    }
}

echo "max = $max";
