<?php
$handle = fopen("../20180419/csv/scores.csv", "r");
while($line = fgets($handle)){
  $results = explode("," ,$line);
  if($results[0] == "tanaka"){
    echo $line;
  }
}
fclose($handle);
