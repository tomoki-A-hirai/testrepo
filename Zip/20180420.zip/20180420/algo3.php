<?php
$numbers = [12, 23, -14, -25, 0, 36];
$sum = 0;

foreach ($numbers as $num) {
  echo "abs = " . abs($num) . PHP_EOL;
}
