<?php
$numbers = [12, 23, -14, -25, 0, 36];
$sum = 0;

foreach ($numbers as $num) {
  if($num > 0){
    $sum += $num;
  }
}
echo "sum = $sum";
