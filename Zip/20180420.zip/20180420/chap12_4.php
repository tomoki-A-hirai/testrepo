<?php
$str = "Object Oriented Programming";

$results = explode(" ",$str);
foreach ($results as $result) {
  echo "$result\r\n";
}
