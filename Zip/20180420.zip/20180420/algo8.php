<?php
function my_abs($array){
  for ($i=0; $i < count($array); $i++) {
    if ($array[$i] < 0) {
      $array[$i] = 0 - $array[$i];
    }
  }
  return $array;
}

function my_max($array){
  $max = 0;
  foreach ($array as $val) {
    if($max < $val){
      $max = $val;
    }
  }
  return $max;
}

$numbers = [12, 23, -14, -25, 0, 36];
$numbers = my_abs($numbers);
$max = my_max($numbers);
echo $max . PHP_EOL;
