function hint() {
  alert("次はブラウザで動的処理を行うための言語に関する記事");
}
