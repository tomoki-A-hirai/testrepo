function hint() {
  alert("最初はMSの三種の神器(?)についての記事");
}
