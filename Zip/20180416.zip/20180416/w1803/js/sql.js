function hint() {
  alert("次はハイパーテキスト作成に関する記事");
}
