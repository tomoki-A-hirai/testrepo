function appendText() {
  var text = document.getElementById("textForm").value;
  var escapedText = escape_html(text);
  document.getElementById("textForm").value = "";
  $("#textUl").append("<li>" + escapedText +"</li>");
}


function escape_html (string) {
  if(typeof string !== 'string') {
    return string;
  }
  return string.replace(/[&'`"<>]/g, function(match) {
    return {
      '&': '&amp;',
      "'": '&#x27;',
      '`': '&#x60;',
      '"': '&quot;',
      '<': '&lt;',
      '>': '&gt;',
    }[match]
  });
}

function hint() {
  alert("最後は目次ページ");
}
