function hint() {
  alert("次はデータをたくさん格納することについての記事");
}
