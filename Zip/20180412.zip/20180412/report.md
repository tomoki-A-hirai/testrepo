# 4/12 (水)
科目:HTML,CSS
Webページの作成

AM:
  HTML



PM:
  SQLテスト
  CSS
  CSSフレームワーク


書き方について
+ mysql : コマンドとして使う場合はこう表記する
+ MYSQL
+ MySQL : 名詞としてつかうときはこのように表記する

ピーエイチピー
PHP

ジャヴァ
Java

ジャヴァスクリプト
Javascript <- 間違い
JavaScript <- 正解

Apache




## フレームワーク

  PHP
  + Symfony
  + CaKePHP

  Java
  + Play
  + Spring
  + Structs

  CSSフレームワーク
  + Bootstrap

##  linter
  構文解析してくれるソフト



## HTML
HTMLは、文書をつくるプログラミング言語

Word
+ 見出し
+ 段落
  改行
+ 箇条書き
+ 表
+ 画像
+ 水平線

markdown
+ #
+ 改行
  br
+ +
+ |label|label|
  |:--|:--|
  |data|data|
+ !\\[\alt\]\\(\\url\\)

HTML
+ h1
+ p
  br
+ ul , ol
+ table
+ img
+ hr : hrizontal line

img タグ
alt属性 : 画像が表示されなかったときに表示される文言を決められる


タグ　＝＞　要素 =Element
タグの中の属性＝Attribute




## embed <- 組み込み、埋め込み


## マッシュアップ
既存の機能（サービスやシステム）を組み合わせて一つのシステムを作成する



local IPv4 addoress
IPv4 アドレス . . . . . . . . . . . .: 192.168.1.43
