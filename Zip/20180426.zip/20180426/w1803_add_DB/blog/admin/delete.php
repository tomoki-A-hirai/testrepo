<?php 
require("../common/functions.php");
session_start();
$userId = $_SESSION["userId"];
if(is_null($userId)){
	send_error_page();
}
$articleId = $_GET["id"];
if(!preg_match('/^([0-9]{1,5})$/',$articleId)){
	send_error_page();
}

delete_article($articleId);
redirect("/admin/index.php");