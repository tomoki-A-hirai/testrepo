<?php
$names = ["hayase", "mikuriya", "satou", "hirai"];
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Array Sample</title>
  </head>
  <body>
    <h1>Name List</h1>
    <ol>
      <?php for($i = 0; $i < count($names); $i++): ?>
        <li><?php echo "$names[$i]" ?></li>
      <?php endfor; ?>
    </ol>
  </body>
</html>
