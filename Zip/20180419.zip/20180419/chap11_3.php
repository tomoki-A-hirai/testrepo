<?php
$handle = fopen("./csv/score.csv" , "r");
if($handle == false){
  die("Error : file not found");
}
while($line = fgets($handle)){
  echo $line;
}

fclose($handle);
