<?php
$scores = [
  'suzuki' => ['math' => 72, 'english' => 90],
  'yamada' => ['math' => 64, 'english' => 82]
];

$mathSum =0;

foreach ($scores as $userScore) {
  $mathSum += $userScore['math'];
}

echo "math score sum =$mathSum";
