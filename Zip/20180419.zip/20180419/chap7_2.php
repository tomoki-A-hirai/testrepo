<?php
function add($x, $y){
  $z = $x + $y;
  echo "$z ,$x ,$y" . PHP_EOL;
  return $z;
}


$sum = add(add(10,20),add(30,40));
echo $sum;
