<?php
$users = [
    "U001" => ["name" => "suzuki", "age" => 20 ],
    "U002" => ["name" => "tanaka", "age" => 22],
    "U003" => ["name" => "yamada", "age" => 23]
];

// echo $users["U001"]["name"] . PHP_EOL;
// echo $users["U001"]["age"] . PHP_EOL;
die("Hello");
var_dump($users);
print_r($users);



// foreach ($users as $user) {
//   foreach ($user as $userProf) {
//     echo $userProf . PHP_EOL;
//   }
// }
