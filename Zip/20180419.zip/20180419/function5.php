<?php
function max_value($points){
  $max = 0;
  for($i = 0; $i < count($points); $i++){
    if($max < $points[$i]){
      $max = $points[$i];
    }
  }
  return $max;
}

$points = [20,42,15,99];
echo max_value($points);
