<?php

$fileData = file_get_contents("./csv/scores.csv");

echo $fileData;
