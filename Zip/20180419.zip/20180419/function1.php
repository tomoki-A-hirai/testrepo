<?php
function sum($a, $b ,$c){
  $total = $a + $b + $c;
  return $total;
}

$x = 2;
$y = 4;
$z = 6;
$total = sum($x, $y, $z);
echo $total;
