<?php
$users = [
  ["hayase","white", 0],
  ["mikuriya","blue",9],
  ["satou","red",4],
  ["hirai", "black", 5]
]
?>

<!DOCTYPE html>
<html lang = "ja" dir ="ltr">
<head>
  <meta charset ="utf-8">
  <title>users sample</title>
</head>

<body>
  <table border="1">
    <tr>
      <th>username</th>
      <th>color</th>
      <th>number</th>
    </tr>
    <?php for($i = 0;$i < count($users); $i++):  ?>
      <tr>
        <?php for($j = 0;$j < count($users[$i]); $j++):  ?>
          <td><?php echo $users[$i][$j]; ?></td>
        <?php endfor ?>
      </tr>
    <?php endfor ?>
  </table>
</body>

</html>
