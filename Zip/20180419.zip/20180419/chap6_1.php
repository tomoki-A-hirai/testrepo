<?php
$users = ["U001" => "suzuki", "U002" => "tanaka", "U003" => "yamada"];

// echo $users["U001"] . PHP_EOL;
// echo $users["U002"] . PHP_EOL;
// echo $users["U003"] . PHP_EOL;
//
// foreach ($users as $user) {
//   echo $user . PHP_EOL;
// }

foreach ($users as $key => $user) {
  echo $key . ":" . $user . PHP_EOL;
}
