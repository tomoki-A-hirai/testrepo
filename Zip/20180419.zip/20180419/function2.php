<?php
function check_age($age){
  if($age >= 20 ){
    return "OK";
  }
  return "NG";
}


echo check_age(19);
