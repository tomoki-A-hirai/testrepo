<?php
$number = [1, 3, 5];
foreach ($number as $num) {
  for($i = 0; $i < $num; $i++){
    echo "*";
  }
  echo PHP_EOL;
}
