<?php
$apple = 100;
$number = 3;

$total = $apple * $number;

echo "Total: $total" . PHP_EOL; 
