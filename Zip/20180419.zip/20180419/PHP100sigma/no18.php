<?php
$array = [[24, 21, 24], [18, 28, 32], [24, 25, 29]];
$rowsum = 0;

echo "Sum(rows):";
for ($i=0; $i < count($array); $i++) {
  $rowsum = 0;
  for ($j=0; $j < count($array[$i]); $j++) {
    $rowsum += $array[$i][$j];
  }
  if($i != (count($array) - 1) ){
    echo " $rowsum,";
  }else{
echo " $rowsum";
  }
}
