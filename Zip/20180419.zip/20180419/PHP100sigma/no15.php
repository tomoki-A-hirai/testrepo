<?php
$descs = [];
$ages = [24, 21, 24, 18, 28, 32, 24, 25, 29];
$max = 0;
$flag = true;
$swapCount = 0;

while($flag){
  $swapCount = 0;
  $max = 0;
  for ($i=0; $i < count($ages) ; $i++) {
    if($max < $ages[$i]){
      $max = $ages[$i];
      $swapCount++;
    }
  }
  for ($i=0; $i < count($ages) ; $i++) {
    if($max == $ages[$i]){
      $ages[$i] = 0;
      break;
    }
  }
  if($swapCount == 0){
    $flag = false;
    break;
  }
  $descs[] = $max;
}

echo "Desc:";
for ($i=0; $i < count($descs); $i++) {
  if($i == (count($descs)-1)){
    echo " $descs[$i]";
  }else{
    echo " $descs[$i],";
  }
}
