<?php
$array = [[24, 21, 24], [18, 28, 32], [24, 25, 29]];
$colSum = 0;
$colCount = 0;

echo "Sum(col) : ";

while($colCount < count($array[0])){
  $colSum = 0;
  for ($i=0; $i < count($array); $i++) {
    $colSum += $array[$i][$colCount];
  }
  if($colCount ==(count($array[0]) - 1)){
    echo " $colSum";
  }else{
    echo " $colSum,";
  }
  $colCount++;
}
