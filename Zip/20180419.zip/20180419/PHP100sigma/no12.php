<?php
$ages = [24, 21, 24, 18, 28, 32, 24, 25, 29];
$sum = 0;


for ($i=0; $i < count($ages); $i++) {
  $sum += $ages[$i];
}

echo "Sum: ".$sum . PHP_EOL;
