<?php
$apple = 100;
$numA = 3;
$banana = 200;
$numB = 2;
$tax = 0.08;


$total = (($apple * $numA) + ($banana * $numB) )* (1 + $tax);

echo "Total: $total" . PHP_EOL;
