<?php
$array = [[24, 21, 24], [18, 28, 32], [24, 25, 29]];
$sum = 0;


for ($i=0; $i < count($array); $i++) {
  for ($j=0; $j < count($array[$i]); $j++) {
    $sum += $array[$i][$j];
  }
}
echo "Sum:$sum";
