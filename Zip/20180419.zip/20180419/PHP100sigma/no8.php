<?php
$fruits = ["Apple", "Banana", "Cherry"];

for ($i=0; $i < count($fruits); $i++) {
  echo ($i + 1) . ":" . $fruits[$i] . PHP_EOL;
}
