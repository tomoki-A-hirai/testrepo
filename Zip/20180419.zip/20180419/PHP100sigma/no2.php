<?php
$count = 3;
$message = "Hello";

for ($i = 0; $i < $count; $i++ ) {
  echo ($i+1) .":$message" . PHP_EOL;
}
