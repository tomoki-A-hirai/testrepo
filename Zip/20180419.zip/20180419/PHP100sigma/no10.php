<?php
$ages = [24, 21, 24, 18, 28, 32, 24, 25, 29];
$min = $ages[0];


for ($i=0; $i < count($ages); $i++) {
  if($min > $ages[$i]){
    $min = $ages[$i];
  }
}

echo "Min: ".$min . PHP_EOL;
