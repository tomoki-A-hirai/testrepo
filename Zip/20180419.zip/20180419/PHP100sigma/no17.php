<?php
$number = [[2, 2], [2, 4], [4, 2]];

foreach ($number as $k => $num) {
  for($i = 0; $i < $num[0]; $i++){
    for ($j = 0; $j < $num[1]; $j++) {
      echo "*";
    }
    echo PHP_EOL;
  }
  if($k != (count($number)-1)){
    echo "-" . PHP_EOL;
  }
}
