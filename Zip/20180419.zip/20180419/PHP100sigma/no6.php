<?php
$fruits = ["Apple", "Banana", "Cherry"];

for ($i=0; $i < count($fruits); $i++) {
  echo $fruits[$i] . PHP_EOL;
}
