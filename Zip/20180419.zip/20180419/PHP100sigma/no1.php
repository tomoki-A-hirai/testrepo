<?php
$count = 3;
$message = "Hello";

for ($i = 0; $i < $count; $i++ ) {
  echo $message . PHP_EOL;
}
