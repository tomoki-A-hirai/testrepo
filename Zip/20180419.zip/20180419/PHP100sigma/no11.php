<?php
$ages = [24, 21, 24, 18, 28, 32, 24, 25, 29];
$max = 0;


for ($i=0; $i < count($ages); $i++) {
  if($max < $ages[$i]){
    $max = $ages[$i];
  }
}

echo "Max: ".$max . PHP_EOL;
