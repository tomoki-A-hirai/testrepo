<?php
$apple = 100;
$number = 3;
$tax = 0.08;


$total = $apple * $number * (1 + $tax);

echo "Total: $total" . PHP_EOL;
