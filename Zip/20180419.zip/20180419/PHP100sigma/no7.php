<?php
$fruits = ["Apple", "Banana", "Cherry"];

for ($i=0; $i < count($fruits); $i++) {
  echo $fruits[(count($fruits)-1)-$i] . PHP_EOL;
}
