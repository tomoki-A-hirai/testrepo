<?php
$ages = [24, 21, 24, 18, 28, 32, 24, 25, 29];

echo "Count : " . count($ages) . PHP_EOL; 
