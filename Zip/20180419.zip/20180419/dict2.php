<?php
$scores = [
  'suzuki' => ['math' => 72, 'english' => 90],
  'yamada' => ['math' => 64, 'english' => 82]
];

echo $scores['yamada']['english'];
