<?php
$scores = [
  'suzuki' => ['math' => 72, 'english' => 90],
  'yamada' => ['math' => 64, 'english' => 82]
];

$total = 0;

foreach ($scores as $key => $score) {
  // echo "$key 's total =  ";
  echo "$key : ";
  foreach ($score as $key => $value) {
    $total += $value;
  }
  echo $total . PHP_EOL;
  $total =0;
}
