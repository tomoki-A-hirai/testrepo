<?php
function add_mark($str){
  return ("*" . $str . "*");
}

echo add_mark("IT CARET");
