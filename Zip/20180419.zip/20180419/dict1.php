<?php
$scores = ['match' => 72, 'english' => 90];

echo $scores['english'];
