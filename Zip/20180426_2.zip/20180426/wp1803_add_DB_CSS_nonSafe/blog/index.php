<?php
  require("../common/functions.php");
  $articles = get_articles();
  $articles = array_reverse($articles);
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?= BLOG_TITLE ?></title>
    <link rel="stylesheet" href="../<?= CSS_FILE ?>">
  </head>
  <body>
    <header class="jumbotron">
        <h1><?= BLOG_TITLE ?></h1>
    </header>
    <hr>
    <h2>Article List</h2>
    <ul>
      <?php foreach ($articles as $article){ ?>
        <li>
          <?= htmlspecialchars($article['date']); ?>
          <a href="show.php?id=<?= $article['id'] ?>">
            <?= htmlspecialchars($article['title']); ?>
          </a>
        </li>
      <?php } ?>
    </ul>
  </body>
</html>
