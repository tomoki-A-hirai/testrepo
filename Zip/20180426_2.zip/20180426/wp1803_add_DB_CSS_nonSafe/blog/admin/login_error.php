<?php
require("../../common/functions.php");
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?= ADMIN_BLOG_TITLE ?></title>
  </head>
  <body>
    <h1><?= ADMIN_BLOG_TITLE ?></h1>
    <hr>
    <h2>Login Error</h2>
    <hr>
    <a href="/admin/login.php">BACK</a>
  </body>
</html>
