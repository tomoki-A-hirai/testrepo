<?php
// TODO
define('ARTICLE_FILE', '/article/article.json');
define('USER_FILE', '/usersInfo/user.csv');
define('BLOG_TITLE', 'T.Hirai Blog');
define('ADMIN_BLOG_TITLE', 'Admin T.Hirai Blog');

define('DEFAULT_ENCODE', 'UTF-8');
define('DOMAIN', 'http://localhost:8000/');

/**
 * リダイレクトする。
 * （処理を終了する）
 * @param string $path リダイレクト先のパス
 */
function redirect($path){
  header('location: ' . DOMAIN . $path);
  exit();
}

/**
 * エラーページに転送する。
 * （処理を終了する）
 * @param string $path リダイレクト先のパス
 */
function send_error_page(){
  header('location: ' . DOMAIN . 'common/error.php');
  exit();
}

/**
 * ログインする。
 * @param string $userId ユーザID
 * @param string $password パスワード
 * @return bool ログイン成功の場合 true
 */
function login($userId, $password) {
  if (file_exists(USER_FILE)) {
    $lines = file(USER_FILE, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
      $user = explode(",", $line);
      if ($userId == $user[0] && $password == $user[1]) {
        return true;
      }
    }
  }
  return false;
}

/**
 * 記事一覧を取得する。
 * @return array 記事の一覧
 */
 
/* function get_articles(){
  if (file_exists(ARTICLE_FILE)) {
    $articles_json = file_get_contents(ARTICLE_FILE);
    $articles = json_decode($articles_json, true);
  }else{
    $articles = [];
  }
  return $articles;
} */

function get_articles(){
	$db = connect_articles();
	$query = "select * from articles";
	$results = mysqli_query($db,$query);
	while($line = mysqli_fetch_assoc($results)){
		if($line != NULL){
			$result[] = $line;
		}
	}
	mysqli_close($db);
	return $result;
}



/**
 * 記事を取得する。
 * @param string $id 記事ID
 * @return array 記事 存在しない場合 null
 */
function get_article($id){
  $articles = get_articles();
  foreach ($articles as $article) {
    if($article['id'] == $id){
      return $article;
    }
  }
  return null;
}

/**
 * 記事を保存する。
 * @param array $new_article 新規記事
 */
function save_article($new_article){
/*   $articles = get_articles();
  $articles[] = $new_article;
  $articles_json = json_encode($articles);
  file_put_contents(ARTICLE_FILE, $articles_json, LOCK_EX); */
  $db = connect_articles();
  $id = $new_article['id'];
  $title = $new_article['title'];
  $body = $new_article['body'];
  $date = $new_article['date'];
  $author = $new_article['author'];
  $query = "insert into articles(id ,title,body,date,author) values($id,'$title','$body','$date','$author' );";
  mysqli_query($db,$query);
  mysqli_close($db);
}

/**
 * 記事を削除する。
 * @param string $id 削除対象の記事ID
 */
function delete_article($id){
 /*  $delete_index;
  //get articles 
  $articles = get_articles();
  //delete article by id
  $count = count($articles);
  for($i = 0; $i < $count; $i++){
	  if($articles[$i]["id"] == $id){
		  $delete_index = $i;
		  break;
	  }
  }
  array_splice($articles,$delete_index,1);
  //save change articles
  $articles_json = json_encode($articles);
  file_put_contents(ARTICLE_FILE, $articles_json, LOCK_EX); */
  $db = connect_articles();
  $query = "delete from articles where id =$id";
  mysqli_query($db,$query);
  mysqli_close($db);
}

/**
 * 記事を更新する。
 * @param string $id 更新対象の記事
 */
function update_article($edit_article){
  $db = connect_articles();
/*   foreach ($articles as &$article) {
    if($article['id'] == $edit_article['id']){
      $article['title'] = $edit_article['title'];
      $article['body'] = $edit_article['body'];
      $article['date'] = $edit_article['date'];
      $article['author'] = $edit_article['author'];
      break;
    }
  }
  $articles_json = json_encode($articles);
  file_put_contents(ARTICLE_FILE, $articles_json, LOCK_EX); */
  $id = $edit_article['id'];
  $title = $edit_article['title'];
  $body = $edit_article['body'];
  $date = $edit_article['date'];
  $author = $edit_article['author'];
  $query = "update articles set title = '$title' ,body = '$body' , date = '$date' , author = '$author' where id = '$id'";
  mysqli_query($db,$query);
  mysqli_close($db);
}

/**
 * 最新の記事IDを取得する。
 * @return int 最新の記事ID
 */
function get_new_article_id(){
  $articles = get_articles();
  $max = 0;
  foreach ($articles as $article) {
    if ($article['id'] > $max) {
      $max = $article['id'];
    }
  }
  return $max + 1;
}

function connect_articles(){
	$link = mysqli_connect("127.0.0.1", "root", "admin", "blog");
	if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
	}
	return $link;
}
