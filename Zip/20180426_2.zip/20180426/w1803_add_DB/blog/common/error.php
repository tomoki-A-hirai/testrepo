<?php
require("./functions.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?= BLOG_TITLE ?></title>
</head>
<body>
  <h1><?= BLOG_TITLE ?></h1>
  <hr>
  <h2>Error</h2>
  <hr>
  <a href="/index.php">BACK</a>
</body>
</html>
