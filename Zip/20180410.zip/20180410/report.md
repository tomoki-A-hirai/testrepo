メモの取り方
markdown
  簡易なHTMLが書ける表記法

ctrl + shift + p でメニューを出して
markdown previewrを起動

# SQLの学習

データの操作は以下の四つがある。
+ Create
+ Read
+ Update
+ Delete

## Mysql 基本コマンド
```sql
  show databases;
  show tables;
  use database_name;
  desc table_name;
```
## Insert文
```sql
  insert into table_name(feildname) values(value);
```

## Select文
```sql
  seect * from book;
```

## データベースの種類
  + KeyValue型データベース
    MemChached
  + ドキュメント指向データベース
    MongoDB

    エンティティ　－＞テーブルと表現される

    entity relationship diagram -> ER図

    例：
    「受講生情報」<-エンティティ
      + 受講生ID    <-属性（attribute）
      + メールアドレス
      + 氏名
      + パスワード

  ## 主キー


  ## 正規化
  正規化の目的は
  One fact One place
  データの重複がない、一つのデータは一つの場所にある
  されど場合によって、環境に合わせて臨機応変に対応しなくてはならない

  開発現場では第三正規系まではよく使われる

## テーブル
+    マスターテーブル　->システムに必要不可欠なテーブル
+    トランザクションテーブル（履歴テーブル）->運用によってレコードが増えていくテーブル

と呼ばれる



## モデリング課題
  問題点の共有
  みんなの話を聞こう
  聞く側になることも大切


## DBモデリング答え合わせ

  ここでは売り上げという言葉を使おう


  商品マスタ
  + 商品ID 主
  + 商品名
  + 価格

  店舗マスタ
  + 店舗ID　主
  + 店舗名
  + 住所
  + 電話番号

  レジマスタ
  + レジID　主
  + 責任者名
  + 店舗ID

  売上
  + 売り上げID　主
  + 売り上げ日時
  + レジID

  売り上げ明細
  + 売り上げID　主　複合
  + 商品ID　　　主　複合
  + 個数
  + 価格


売り上げ明細（another）
+ 売り上げID
+ 明細番号
+ 商品ID
+ 価格　<- 価格の変動が起きることがあるから


マスタは常に最新のものなので
当時の価格がわからないことで問題が発生することがあると考えられるから




# SQL

## SQL
  SQL = structure query language

## SQLの種類
 + DML - data manipulation language データ操作言語
         Select文
         Insert文
         Update
         Delete

 + DDL - data definition language データ定義言語
        Create
        alter
        drop

 + DCL - data control language データ制御言語
        トランザクションを制御するためのもの
        SETTRANSACTION コマンドでトランザクションを開始できる
