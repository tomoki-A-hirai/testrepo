function greet(){
  alert("Hello World!");
}


function hello() {
  for(var i = 0;i < 3; i++){
      alert("Hello World!");
  }
}

function hello2(){
  document.getElementById("text").value = "aaa";
}
