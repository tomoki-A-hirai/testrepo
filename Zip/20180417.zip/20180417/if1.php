<?php
  $age = 10;
  if($age >=20){
    echo "OK!" . PHP_EOL;
  }else{
    echo "NG!" . PHP_EOL;
  }
