<?php
$apple = 100 * 3;
$orange = 200 * 4;
$x = 10 % 3;

$total = $apple + $orange;

echo $total . PHP_EOL;
echo $x;
