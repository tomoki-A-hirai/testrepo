<?php
  $point1 = 60;
  $point2 = 70;
  $point3 = 30;
  $point4 = 40;

  $total = $point1 + $point2 + $point3 + $point4;
  $avg = $total/4;

  echo $avg;
