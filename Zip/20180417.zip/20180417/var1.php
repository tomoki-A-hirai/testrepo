<?php
  $age = 20;
  echo $age;
