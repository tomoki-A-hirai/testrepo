<?php
$i = 0;
//$i = $i + 1;
$i++;
//$i += 1;

echo $i;
