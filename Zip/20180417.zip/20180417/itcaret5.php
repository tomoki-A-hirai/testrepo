<?php
  $name = "John";
  //$name2 = strtoupper($name);
  $name2 = strtolower($name);
  echo $name2;
?>
