<?php
  $point1 = 80;
  $point2 = 70;
  $point3 = 90;
  $point4 = 60;
  $total = 0;
  for($i = 1;$i<5;$i++){
    $total += ${"point".$i};
  }
  echo $total;
