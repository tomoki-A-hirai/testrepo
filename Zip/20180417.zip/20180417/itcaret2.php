<?php
  $name = ["John","Paul","George"];
  echo "Hello";
  echo $name[0];
  echo "Hello";
  echo $name[1];
  echo "Hello";
  echo $name[2];
?>
