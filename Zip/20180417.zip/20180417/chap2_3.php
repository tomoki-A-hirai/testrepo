<?php
  $name = "JoJo";
  $greeting = "Hello,";
  $itumono = "I quit man!";

  echo $itumono . $name;
