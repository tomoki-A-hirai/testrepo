<?php
  $point = 50;
  $point += 20;

  echo $point;
