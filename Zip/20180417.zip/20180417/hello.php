<?php
  $title = "Hello Java";
  $body = "table body";
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $title; ?></title>
  </head>
  <body>
    <h1><?php echo $title; ?></h1>
    <table border = "1">
      <?php for($i = 0;$i<3;$i++): ?>
        <tr>
          <td><?php echo $body; ?></td>
        </tr>
      <?php endfor; ?>
    </table>
  </body>
</html>
