<?php
  $name = "John";
  echo "Hello";
  echo $name;

  $name = "Paul";
  echo "Hello";
  echo $name;

  $name = "George";
  echo "Hello";
  echo $name;

?>
