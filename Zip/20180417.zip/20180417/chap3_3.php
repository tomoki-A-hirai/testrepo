<?php
  $a =1;
  $b = "1";

  $c = (int)$b;

  if($a === $c){
    echo "same";
  }else{
    echo "different";
  }
