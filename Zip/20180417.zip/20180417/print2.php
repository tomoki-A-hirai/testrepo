<?php
  echo "PHP";
  echo PHP_EOL;

  echo "Java";
  echo PHP_EOL;

  echo "Ruby";
  echo PHP_EOL;
?>
