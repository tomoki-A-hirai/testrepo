<?php
  for($i = 1;$i < 11 ; $i++){
    echo $i;
  }
?>
