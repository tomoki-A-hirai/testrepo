<?php
  $name = "Johnt";
  if($name == "John"){
    echo "Hello";
  }else{
    echo "Good Bye";
  }
?>
