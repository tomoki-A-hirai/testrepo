<?php
//$_POST POSTパラメータ
// $argv 起動引数（実行時引数）
// $score = $argv[1];
// echo $argc . PHP_EOL;
// foreach ($argv as $val) {
//   echo $val . PHP_EOL;
// }


  $score = 90;
  if($score >= 80){
    echo "OK" . PHP_EOL;
  }else{
    echo "NG" . PHP_EOL;
  }
