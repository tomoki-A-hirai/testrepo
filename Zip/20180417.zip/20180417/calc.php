<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Clac Sample</title>
  </head>
  <body>
    <h1>Answer :
    <?php
      echo $_POST["x"] + $_POST["y"];
    ?>
    </h1>
    <a href="./input.html">back to input page</a>
  </body>
</html>
