<?php
  $name = ["John","Paul","George","Ringo"];
  for($i = 0;$i < 4 ;$i++){
    if($i < 2){
      echo "Hello ";
      echo strtoupper($name[$i]);
    }else{
      echo "Goodbye ";
      echo strtolower($name[$i]);
    }
    echo "\n";
  }
?>
