<?php
  $age = $argv[1];
  $license = $argv[2];

  if($license == true && $age >= 20){
    echo "OK" . PHP_EOL;
  }else{
    echo "NG" . PHP_EOL;
  }
