<?php
  // $age = 19;
  // $student = false;

  $age = $argv[1];
  $student = $argv[2];


  var_dump($argv);

  if($age <= 20 && $student == false){
    echo "NG!" . PHP_EOL;
  }else{
    echo "OK!" . PHP_EOL;
  }
