<?php
  //$height = 180;
  // $height = $argv[1];
  // if($height >= 180){
  //   echo "Large" .PHP_EOL;
  // }else if(170 <=$height && $height < 180 ){
  //   echo "Medium" .PHP_EOL;
  // }else{
  //   echo "Small" .PHP_EOL;
  // }



  $height = $argv[1];
  if($height >= 180){
    echo "Large" .PHP_EOL;
  }else if(170 <=$height ){
    echo "Medium" .PHP_EOL;
  }else{
    echo "Small" .PHP_EOL;
  }
