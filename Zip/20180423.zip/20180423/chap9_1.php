<?php
$target = 22;
$number = [12,23,-14,-25,0,36];

$exist = false;
for ($i=0; $i < count($number); $i++) {
  if($number[$i] == $target){
    $exist = true;
    break;
  }
}

if ($exist) {
  echo "Found" . PHP_EOL;
}else{
  echo "Not Found" . PHP_EOL;
}
