<?php
$users = ["U002" => "suzuki", "U001" => "tanaka" , "U003" => "yamada"];
ksort($users);

var_dump($users);
