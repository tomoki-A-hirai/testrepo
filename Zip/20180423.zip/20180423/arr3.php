<?php
$array = ['three' => 3, 'four' => 4 , 'five' => 5];
$array = array_reverse($array);
print_r($array);
