<?php
function fizzbuzz($start, $end,$multi3Str,$multi5Str){
  $array = [];
  for ($i = $start; $i < $end+1; $i++) {
    if ($i % 3 == 0 && $i % 5 == 0) {
      $array[] = $multi3Str.$multi5Str;
    }else if($i % 3 == 0){
      $array[] = $multi3Str;
    }elseif ($i % 5 == 0) {
      $array[] = $multi5Str;
    }else {
      $array[] = $i;
    }
  }
  return $array;
}
$start = 1;
$end = 30;
$multi3Str = "Fizz";
$multi5Str = "Buzz";
$array = fizzbuzz($start, $end,$multi3Str,$multi5Str);
foreach ($array as $val) {
  echo $val . PHP_EOL;
}
