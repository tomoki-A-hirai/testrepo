<?php
$users = ["U002" => "suzuki", "U001" => "tanaka" , "U003" => "yamada"];
ksort($users);

print_r($users);
