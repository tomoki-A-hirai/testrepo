<?php
	$members = ["Oishi", "Sano", "Kawano", "Saito", "Doi"];
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
	<ul>
		<?php foreach($members as $member): ?>
		<li><?= $member ?></li>
		<?php endforeach; ?>
	</ul>

  </body>
</html>
