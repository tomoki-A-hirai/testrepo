<?php
$numbers = [12,23];
rsort($numbers);
foreach ($numbers as $val) {
  echo $val . PHP_EOL; 
}
