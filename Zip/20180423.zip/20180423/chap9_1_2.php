<?php
$target = 56;
$numbers = [12,23,34,45,56,78];

$left = 0;
$right = count($numbers) - 1;

$exist = false;
while($left <= $right){
  $mid = (int)(($left + $right)/2);
  if($numbers[$mid] > $target){
    $right = $mid -1;
  }else if($numbers[$mid] < $target){
    $left = $mid + 1;
  }else{
    $exist = true;
    break;
  }
}


if($exist){
  echo "Found" . PHP_EOL;
}else{
  echo "Not FOUND" . PHP_EOL ;
}
