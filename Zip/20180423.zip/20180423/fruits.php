<?php

function show_fruits($order){
  $handle = fopen("./fruits.txt" , "r");
  $i=1;
  if($order){
    while ($line = fgets($handle)) {
      echo "$i : " . strtoupper($line);
      $i++;
    }
  }else{
    while ($line = fgets($handle)) {
      echo strtoupper($line);
    }
  }
  fclose($handle);
}

show_fruits(true);
show_fruits(false);
