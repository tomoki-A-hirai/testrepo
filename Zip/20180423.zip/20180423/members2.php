<?php
  $members = [
    ["Oishi",22,"Java","image1.png"],
    ["Sano",22,"Ruby","image2.png"],
    ["Kawano",21,"Python","image3.png"],
    ["Saito",22,"PHP","image4.png"],
    ["Doi",23,"Perl","image5.png"]
];
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <table>
      <tr>
        <th>Name</th>
        <th>Age</th>
        <th>Fav</th>
        <th>Image</th>
      </tr>
      <?php foreach ($members as $member): ?>
        <tr>
          <td><?= $member[0] ?></td>
          <td><?= $member[1] ?></td>
          <td><?= $member[2] ?></td>
          <td><img src="./img/<?= $member[3] ?>" alt="show favicon"></td>
        </tr>
      <?php endforeach; ?>

    </table>
  </body>
</html>
