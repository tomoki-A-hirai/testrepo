<?php
$numbers = [12,23,-14,-25,0,36];
echo count($numbers) . PHP_EOL;
