<?php
$array = ['one', 'two', 'three', 'four', 'five'];
$array = array_slice($array,2,2);
print_r($array);
