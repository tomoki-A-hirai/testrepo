<?php
$numbers = [12,23,-14,-25,0,36];
$result = array_slice($numbers , 1 , 2);
foreach ($result as $elem) {
  echo $elem . PHP_EOL;
}
