<?php
function print_fruits($strupper,$order){
  $rows = file("./fruits.txt", FILE_IGNORE_NEW_LINES);
  foreach ($rows as $key => $val) {
    if($order && $strupper){
      echo ($key + 1)." : " . strtoupper($val) . PHP_EOL;
    }else if($strupper){
      echo strtoupper($val) . PHP_EOL;
    }else if($order){
      echo ($key + 1) ." : $val";
    }else{
      echo $val . PHP_EOL;
    }
  }
}


print_fruits(true,true);
