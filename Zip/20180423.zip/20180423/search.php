<?php
$keyword = $_POST["keyword"];
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    Input Keyword : <?= htmlspecialchars($keyword); ?>
  </body>
</html>
