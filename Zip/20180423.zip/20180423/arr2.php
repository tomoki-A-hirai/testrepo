<?php
$array = ['one', 'two', 'three', 'four', 'five'];

$replace = array(2 => "oen",3 => "three" , 4 => "two");
$array = array_reverse($array);
$array = array_replace($array,$replace);

print_r($array);
