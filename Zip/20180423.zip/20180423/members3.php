<?php
  $info = [];
  $members = file("./csv/members.csv",FILE_IGNORE_NEW_LINES);
  foreach ($members as $member) {
    $info[] = explode(",",$member);
  }
?>

<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>IT CARET</title>
  </head>
  <body>
    <table>
      <tr>
        <th>Name</th>
        <th>Age</th>
        <th>Fav</th>
        <th>Image</th>
      </tr>
      <?php foreach ($info as $member): ?>
        <tr>
          <td><?= $member[0] ?></td>
          <td><?= $member[1] ?></td>
          <td><?= $member[2] ?></td>
          <td><img src="./img/<?= $member[3] ?>" alt="show favicon"></td>
        </tr>
      <?php endforeach; ?>

    </table>
  </body>
</html>
