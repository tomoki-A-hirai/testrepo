<?php
$title = "Hello PHP";
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?= $title ?></title>
  </head>
  <body>
    <h1><?= $title ?></h1>
  </body>
</html>
