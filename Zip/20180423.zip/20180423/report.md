# 4/23
科目 : PHP

内容 :
  AM : 復習
        アルゴリズム残り
        PHP-Web編

  PM : リクエスト
        レスポンス
        Cookie
        Session


# 朝一プログラミング復習
##  FizzBuzz.php作成
  ただしFizzBuzz関数を定義して実装してください
  引数
    + 開始の位置
    + 終了の位置
    + 3の倍数で出力する文字列
    + 5の倍数で出力する文字列
  戻り値
  fizzbuzz配列

## ファイルを扱うプログラム
  fruits.txtを読み込んで
  行番号とデータを表示する関数を作成します

  関数名 show_fruits
    引数 :
      行番号表示有無
    戻り値 :
      なし

## プログラミングの習得
    組み込み関数を覚えてほしい
    大きく分けて3つ
  + String関数(strtoupper substr strstr)
  + Collection関数(count array_slice in_array array_search)
  + IO関数(fopen fgets file file_get_contents)


# 学習する習慣をつけることが研修のゴール

# 技術力と才能
技術力 = 才能 * 努力
Skill = Avility * effort
Result = Skill * Effort;

grid やりぬく力　引用

#知らなかったで済まされないセキュリティ知識
XSS - 不正なJSを埋め込まれる
SQL Injection - 不正なSQLを埋め込まれる
CSRF シーサーフ - 登録URLに、外部のWebサイトからデータを送信できてしまう
