<?php
$numbers = [12,23,-14,-25,0,36];
$target = 36;

$result = in_array($target , $numbers);
var_dump($result);

$result = array_search($target , $numbers);
var_dump($result);
