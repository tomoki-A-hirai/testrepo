<?php
$queue = [];

array_push($queue,"A");
array_push($queue,"B");
array_push($queue,"C");
print_r($queue);

echo array_pop($queue) . PHP_EOL;
print_r($queue);

echo array_pop($queue) . PHP_EOL;
print_r($queue);
