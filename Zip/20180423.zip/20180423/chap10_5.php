<?php
$numbers = [12,23,-14,-25,0,36];
sort($numbers);

foreach ($numbers as $elem) {
  echo $elem . PHP_EOL;
}
