<?php
$users = ["U001" => "suzuki", "U002" => "tanaka" , "U003" => "yamada"];
$target = "U005";

$result = array_key_exists($target, $users);
var_dump($result);
